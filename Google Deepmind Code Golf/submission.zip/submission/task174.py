def p(e):
 a=len(e)
 def t(p,r):
  if a>p>=0<=r<a and e[p][r]==u and(p,r)not in i:i.add((p,r));[t(p+a,r+i)for a in(-1,0,1)for i in(-1,0,1)if a|i]
 for p in range(a):
  for r in range(a):
   if(u:=e[p][r]):
    i=set();t(p,r);i,r=zip(*i);n,q=min(i),max(i);i,r=min(r),max(r);b=[a[i:r+1]for a in e[n:q+1]]
    if b==[a[::-1]for a in b]:return b