def p(p,R=range):
 o=[r[:]for r in p];b,b=len(p),len(p[0]);a={(r,c)for r in R(b)for c in R(b)if p[r][c]==3};t=set()
 for k in[3,2,1]:
  for r in R(b):
   for c in R(b):
    for p in[0,1]:
     f,l,e,c3=(c+k,c,c-k,c+2*k)if p else(c,c+k,c+2*k,c-k);n=set()
     for d in R(k):
      for p in R(k):
       if 0<=r+d<b and 0<=f+p<b:n.add((r+d,f+p))
       if 0<=r+d+k<b and 0<=l+p<b:n.add((r+d+k,l+p))
     if len(n)==2*k*k and n<=a and not n&t:
      t|=n
      for d in R(k):
       for p in R(k):
        if 0<=r+d-k<b and 0<=e+p<b:o[r+d-k][e+p]=8
        if 0<=r+d+2*k<b and 0<=c3+p<b:o[r+d+2*k][c3+p]=8
 return o