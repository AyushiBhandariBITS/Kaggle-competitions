def p(g):
 h=len(g);w=len(g[0]);s=sum(g,[]);k=s.index(8);d=s[k+w-1:k+w]==[8]
 for a in-1,1:
  b=a-2*a*d;y,x=divmod(k,w)
  while 0<=y+a<h and 0<=x+b<w:
   Y=y+a;X=x+b;R=g[Y];v=R[X]
   if v-2:y,x=Y,X;R[X]=v or 3
   R==[2]*w and(a:=-a)
   all(r[X]==2 for r in g)and(b:=-b)
 return g