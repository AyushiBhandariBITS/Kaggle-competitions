def p(g,i=range):
 a=[r[:]for r in g];f=[]
 for r in a:f+=[[x for s in r for x in(s,s)] for _ in(0,1)]
 h,e=len(f),len(f[0]);v=[[0]*e for _ in i(h)];q=[]
 for r in i(h):
  for c in i(e):
   if f[r][c]!=2 or v[r][c]:continue
   d=[(r,c)];v[r][c]=1;k=[]
   while d:
    y,x=d.pop();k+=[(y,x)]
    for j in(-1,0,1):
     for b in(-1,0,1):
      if j|b==0:continue
      u,V=y+j,x+b
      if 0<=u<h and 0<=V<e and not v[u][V] and f[u][V]==2:v[u][V]=1;d+=[(u,V)]
   q+=[k]
 n={(r,c)for r in i(h)for c in i(e)if f[r][c]==2}
 g=lambda p,m,n,h:[f.__setitem__(x,f[x][:m]+[4]*(h-m)+f[x][h:])for x in i(p,n+1)]
 for o in q:k=[r for r,_ in o];l=[c for _,c in o];g(min(k),min(l),max(k),max(l))
 a=lambda A,B:min(abs(x-u)+abs(y-v)for x,y in A for u,v in B)
 for r in i(len(q)):
  for c in i(len(q)):
   if a(q[r],q[c])<5:y=q[r]+q[c];k=[r for r,_ in y];l=[c for _,c in y];g(min(k),min(l),max(k),max(l))
 for r,c in n:f[r][c]=2
 return[f[x][::2]for x in i(0,h,2)]