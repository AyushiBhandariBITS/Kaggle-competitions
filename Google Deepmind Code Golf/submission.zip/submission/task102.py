R,M,N=range,max,min
from collections import*
def p(g):
 h,w=len(g),len(g[0]);B=M(Counter(v for r in g for v in r),key=lambda x:sum(r.count(x)for r in g));v=[[0]*w for _ in g];C=[]
 for i in R(h):
  for j in R(w):
   if v[i][j]or g[i][j]==B:continue
   q=deque([(i,j)]);v[i][j]=1;s={(i,j)};c=g[i][j]
   while q:
    x,y=q.popleft()
    for a,b in((1,0),(-1,0),(0,1),(0,-1)):
     X,Y=x+a,y+b
     if 0<=X<h and 0<=Y<w and not v[X][Y]and g[X][Y]==c:v[X][Y]=1;q.append((X,Y));s.add((X,Y))
   C+=s,
 F=set()
 for s in C:
  a,b=N(i for i,_ in s),N(j for _,j in s);A,B=M(i for i,_ in s),M(j for _,j in s)
  H={(i,j)for i in R(a,A+1)for j in R(b,B+1)if(i,j)not in s}
  if H:
   x1,y1=N(i for i,_ in H),N(j for _,j in H);x2,y2=M(i for i,_ in H),M(j for _,j in H);Hh=x2-x1+1;Ww=y2-y1+1
   if Hh==Ww and len(H)==Hh*Ww:F|=H
 if not F:return g
 G=[list(r)for r in g]
 for i,j in F:G[i][j]=2
 return G