e=range
def p(u):
 h=sum(u,[]);c=h.count(0);t=9-c;i=[[0]*(c*3)for h in e(c*3)]
 for m in e(t):
  for o in e(3):
   for n in e(3):
    if u[o][n]:i[o+m//c*3][n+m%c*3]=max(h)
 return i