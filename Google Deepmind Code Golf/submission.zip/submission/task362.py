e,g=range,len
def p(d):
 r=sum(d,[]).count(5);a=[i for i in e(g(d))if d[i].count(0)==0][0];f=d[a][0];s=d[0].index(f)
 for i in e(g(d)):
  for u in e(g(d[0])):
   if i==a+r or u==s-r:d[i][u]=f
   else:d[i][u]=0
 return d