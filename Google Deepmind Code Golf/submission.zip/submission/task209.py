from itertools import product as P,groupby as G
def p(b):
 R,L,M,N,E=range,len,min,max,next;r,c=L(b),L(b[0]);d=sorted((y,x)for y,x in P(R(r),R(c))if b[y][x]==4)
 if L(d)!=4:return[]
 A,S,B,D=d[0]+d[3];e=[(y,x)for y,x in P(R(r),R(c))if b[y][x]and not(A<=y<=B>=A and S<=x<=D>=S)]
 if not e:return[[4if(y,x)in((0,0),(0,D-S),(B-A,0),(B-A,D-S))else 0 for x in R(D-S+1)]for y in R(B-A+1)]
 f,g=M(y for y,_ in e),M(x for _,x in e);h=[(y,x)for y in R(A,B+1)for x in R(S,D+1)if b[y][x]not in(0,4)]
 if not h:r=[[0]*(D-S+1)for _ in R(B-A+1)];r[0][0]=r[0][-1]=r[-1][0]=r[-1][-1]=4;return r
 a=lambda b,A,B,S,D:(m:=1e9,[m:=M(m,N(sum(1for _ in g)for _,g in G(a)))for a in([[b[y][x]for x in R(S,D+1)if b[y][x]not in(0,4)]for y in R(A,B+1)]+[[b[y][x]for y in R(A,B+1)if b[y][x]not in(0,4)]for x in R(S,D+1)])if a],m if m!=1e9 else 1)[-1]
 l=a(b,A,B,S,D);m={}
 for y,x in h:v=b[y][x];m[v]=m.get(v,[[b[y+dy][x+dx]if 0<=y+dy<r and 0<=x+dx<c else 0 for dx in R(l)]for dy in R(l)])
 o=h[0];v=b[o[0]][o[1]];n=E(((y-f,x-g)for y,x in e if b[y][x]==v),(-1,-1))
 C=lambda Y,X:(Q:=[[0]*(D-S+1)for _ in R(B-A+1)],Q[0].__setitem__(0,4),Q[0].__setitem__(-1,4),Q[-1].__setitem__(0,4),Q[-1].__setitem__(-1,4),[(mm:=m.get(b[y][x],[[b[y][x]]*l]*l),yy:=Y+(y-f)*l,xx:=X+(x-g)*l,[(0<=yy+q<L(Q)and 0<=xx+w<L(Q[0])and Q[yy+q].__setitem__(xx+w,mm[q][w]))for q,w in P(R(l),repeat=2)])for y,x in e],Q)[-1]
 Y=(o[0]-A)-n[0]*l if n!=(-1,-1)else 0;X=(o[1]-S)-n[1]*l if n!=(-1,-1)else 0;Q=C(Y,X)
 if any(b[y][x]not in(0,4)and not Q[y-A][x-S]for y,x in P(R(A,B+1),R(S,D+1))):
  K,z,v=E((y,x,b[y][x])for y in range(B,A-1,-1)for x in range(S,D+1)if b[y][x]not in(0,4));T=[(y,x)for y,x in e if b[y][x]==v];i,j=max(y for y,_ in T),M(x for _,x in T);Y=(K-A)-((i-f)*l+l-1);X=(z-S)-(j-g)*l;Q=C(Y,X)
 return Q