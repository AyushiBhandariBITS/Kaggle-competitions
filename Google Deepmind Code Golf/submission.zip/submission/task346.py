def p(g):
 for i in range(1,len(g)-1):
  for j in range(1,len(g[0])-1):
   if g[i][j]and len(s:={g[i+a][j+b]for a in(-1,0,1)for b in(-1,0,1)if a|b})<2and s.pop():return[[g[i][j]]]