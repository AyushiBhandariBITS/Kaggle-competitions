def p(t):
 p=range;n=[e[:]for e in t];e=[(e,n)for e in p(len(t))for n in p(len(t[0]))if t[e][n]==8]
 if e:
  l,o=min(e for(e,p)in e),max(e for(e,p)in e);d,e=min(e for(p,e)in e),max(e for(p,e)in e)
  for l in p(l,o+1):
   for e in p(d,e+1):
    if t[l][e]==1:n[l][e]=3
 return n