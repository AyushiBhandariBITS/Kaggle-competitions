def p(i):
 e=range;n=[n[:]for n in i]
 def d(c,r,i):
  if 0<=c<10and 0<=r<10and n[c][r]==5:n[c][r]=i;[d(c+n,r+o,i)for(n,o)in[(-1,0),(1,0),(0,-1),(0,1)]]
 [[d(e,o,i[0][o])for e in e(1,10)if n[e][o]==5]for o in e(10)if i[0][o]];return n