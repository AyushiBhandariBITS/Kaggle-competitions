def p(r):
 m=max({e:sum(e.count(e)for e in r)for e in sum(r,[])}.items(),key=lambda e:e[1])[0];c=[[0]*15for e in range(5)];s=[]
 for e in range(5):
  for p in range(15):
   if not c[e][p]and r[e][p]!=m:
    f=[(e,p)];d=[]
    while f:
     e,u=f.pop()
     if 5>e>=0<=u<15and not c[e][u]and r[e][u]!=m:c[e][u]=1;d+=[(e,u)];f+=[(e+m,u+x)for m,x in[(0,1),(0,-1),(1,0),(-1,0)]]
    if d:s.append({(r[e][s],(e,s))for e,s in d})
 i=s[0];c,m=min(s[0]for e,s in i),min(s[1]for e,s in i);s={(c,(s[0]-c,s[1]-m))for c,s in i};k=max(s[1]for e,s in s)+1;s=next((p for p in range(1,k)if {(c,(e,u-p))for c,(e,u)in s if u-p>=0}.issubset(s)),k)
 for c,(e,u)in i:
  f=s
  while u+f<15:r[e][u+f]=c;f+=s
 return r