def p(g):
 for i,c in enumerate(g[0][1:-1],1):
  if c:g[1][i-1:i+2:2]=c,c
 g[2:]=g[:-2];g[2:]=g[:-2];return g