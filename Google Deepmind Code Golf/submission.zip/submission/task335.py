def p(b,t=range):
 i=lambda r:next((i,x.index(r))for(i,x)in enumerate(b)if r in x);r,x=i(8);i,n=i(2)
 for f in t(r+1,i+1)if r<i else t(i,r):b[f][x]=4
 for f in t(x,n)if x<n else t(n+1,x):b[i][f]=4
 return b