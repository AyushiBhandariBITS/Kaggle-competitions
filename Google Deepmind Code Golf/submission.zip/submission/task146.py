T=tuple
def p(g):
 for i in 0,3,6:
  a=g[i:i+3];A=T(map(T,a))
  if(A==T(x[::-1]for x in zip(*a[::-1])))+(A==T(zip(*a)))<1:return a