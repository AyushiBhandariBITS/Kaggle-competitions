def p(g):
 a=[[3]*4+[0]*5]*4+[[0]*4+[3]*4+[0]]*4+[[0]*9]
 for k in g[0][0],g[0][2],g[2][2],g[2][0]:
  if k:break
  a=[*map(list,zip(*a[::-1]))]
 return a