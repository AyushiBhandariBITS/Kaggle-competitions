def p(j):
 for w in j:
  if w[0]:w[:]=w[:1]*5+[5]+w[-1:]*5
 return j