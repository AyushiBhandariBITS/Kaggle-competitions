q,o=range,len
def p(t):
 i,i=o(t),o(t[0]);p=t[0][i//2];n=[[0]*(i-1)for n in q(i-1)]
 for r in q(i//2):
  u=~r
  for e in q(i//2):c=~e;a=p*(t[r][e]>0);n[r][e]=n[u][e]=n[u][c]=n[r][c]=a
 return n