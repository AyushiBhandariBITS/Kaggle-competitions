R=range;L=len
def p(g):
 C,D=L(g),L(g[0])
 for E in R(10):
  for A in R(C):
   for B in R(D):
    if g[A][B]==0:g[A][B]=g[B][A]
    if g[A][B]==0:g[A][B]=g[A+1][B+1]
 return g