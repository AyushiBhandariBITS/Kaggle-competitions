def p(i,r=range):
 l=sum(i[d][h]==i[d][h+1]==i[d+1][h]==i[d+1][h+1]==2for d in r(len(i)-1)for h in r(len(i)-1));d=[[0]*3for d in'***']
 for h in r(l):d[h*2//3][h*2%3]=1
 return d