def p(j,A=range):
 c,e=len(j),len(j[0]);k,w,l,B=c,0,e,0
 for a in A(c):
  for b in A(e):
   if j[a][b]>1:k=min(k,a);w=max(w,a);l=min(l,b);B=max(B,b)
 return [[x-(x==1)for x in r[l:B+1]]for r in j[k:w+1]]