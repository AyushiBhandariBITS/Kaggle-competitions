e=range;f=len
def p(g):
 p,i=f(g),f(g[0]);r=[[0]*3for r in e(3)];t=min([r for r in e(p)if g[r].count(5)>0]);d=min([r.index(5)for r in g if r.count(5)>0]);g=[r[d:d+9]for r in g[t:t+9]]
 for d in e(0,9,3):
  for p in e(0,9,3):r[d//3][p//3]=g[d][p]
 g=[[r[t//3][d//3]and r[t%3][d%3]for d in e(9)]for t in e(9)];return g