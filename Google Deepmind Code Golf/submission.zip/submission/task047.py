def p(f):
 d=range;r=[[0]*9for r in d(9)];i=[(r,i,f[r][i])for r in d(9)for i in d(9)if f[r][i]]
 for(d,n,u)in i:
  for f in range(9):r[d][f]=r[f][n]=u
 r[i[0][0]][i[1][1]]=r[i[1][0]][i[0][1]]=2;return r