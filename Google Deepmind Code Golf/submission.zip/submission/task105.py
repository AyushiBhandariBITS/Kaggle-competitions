f,M,N=lambda b:list(zip(*b[::-1])),max,min
def p(b,i=len,a=range):
 z=[e[:]for e in b]
 for e in a(4):
  b=f(b);z=[list(e)for e in f(z)];g,n=i(b),i(b[0]);t=[(e,t)for e in a(g)for t in a(n)if b[e][t]==1]
  if t:
   x,s,o,d=N(e for(e,t)in t),M(e for(e,t)in t),N(e for(t,e)in t),M(e for(t,e)in t)
   for e in a(g-1):
    for t in a(n-2):
     m=[t for t in a(n)if z[e][t]>0]
     if m and i(m)>3:
      if b[e][t]==1and b[e][t+2]==1:z[e][t+1]=2
      if b[e][t]==1and b[e+1][t+1]==1:z[e][t+1]=2
      if N(m)<t+1<M(m)and b[e][t+1]==0:z[e][t+1]=2
   for e in a(g):
    if e==x or e==s:
     for t in a(o,d+1):
      if z[e][t]==0:z[e][t]=2
   for t in a(n):
    if t==o or t==d:
     for e in a(x,s+1):
      if z[e][t]==0:z[e][t]=2
 g,n=i(b),i(b[0])
 for e in a(g):
  for t in a(n):
   if b[e][t]>0:z[e][t]=1
 return z